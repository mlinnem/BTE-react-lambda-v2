exports.SESSION_IDENTIFIER = "session";
